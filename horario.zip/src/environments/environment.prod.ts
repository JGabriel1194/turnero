export const environment = {
  production: true,
  apiUrl:'https://sindi-api.herokuapp.com'
  //apiUrl:'http://localhost:4000'
};
