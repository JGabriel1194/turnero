export class Dia {
    constructor(){
        this.id = '',
        this.dia_nombre = ''
    }
    id: string;
    dia_nombre: string;
}