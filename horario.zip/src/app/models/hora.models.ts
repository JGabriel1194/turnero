export class Hora {
    constructor(){
        this.id = '',
        this.hora_inicio = ''
    }
    id: string;
    hora_inicio: string;
}